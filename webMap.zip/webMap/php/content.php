<div id='content-t'>
<?php

if(isset($_GET['xem'])){
	switch($_GET['xem']){
		case 'themtuyenbus': 
			include("php/content/themTuyenbus.php");
			break;
		case 'timtuyenbus': 
			include("php/content/timTuyenbus.php");
			break;
		case 'danhsachtuyenbus': 
			include("php/content/danhSachtuyenbus.php");
			break;
		case 'danhsachtrambus':
			include("php/content/danhSachtrambus.php");
			break;
		default:{
			//include("");
		}

	}
} 
?>
</div>