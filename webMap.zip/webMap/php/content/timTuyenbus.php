
		<button style="position: absolute;top: 10px; left: 5px;" onclick="get_toado_bus();">Tìm</button>
		 		<div id="form">
			            <form action="javascript:submitQuery()">
			                <label> From</label>
			                <input type="text" name="from-point" />
			                <label> To </label>
			                <input type="text" name="to-point"></input>
			                <input type="submit" value="Submit"></input>
			            </form>
			    </div>

				<div id="mapid" style="width: 1080px; height: 600px;"></div>
			</div>
		<script>
			var mymap = L.map('mapid').setView([10.775375, 106.705737], 14);
			var marker = L.marker([10.775375, 106.705737]).addTo(mymap);
			marker.bindPopup("<b>HCMCT</b>").openPopup();
			L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
				maxZoom: 18,
				attributionControl: false,
				prefix: '',
			}).addTo(mymap);
			var popup = L.popup();

			function onMapClick(e) { 
				    popup
				        .setLatLng(e.latlng)
				        .setContent("Vị trị của bạn là " + e.latlng.toString())
				        .openOn(mymap);
				}
				mymap.on('click', onMapClick);
			
				//search
				var searchControl = L.esri.Geocoding.geosearch().addTo(mymap);
				var results = L.layerGroup().addTo(mymap);
					searchControl.on('results', function(data){
					results.clearLayers();
				    for (var i = data.results.length - 1; i >= 0; i--) {
				      results.addLayer(L.marker(data.results[i].latlng));
				    }
				  });
				//Đọc file geojson
				//var geojsonLayer = new L.GeoJSON.AJAX("/mygeodata/geojson.geojson");       
				//geojsonLayer.addTo(mymap);
				//Hiện thông tin
				/*var layerGroup = L.geoJSON(properties, {
					  onEachFeature: function (feature, layer) {
					    layer.bindPopup('<h1>id:'+feature.properties. id+'</h1><p>name:'+feature.properties.name+'</p>'+'</h1><p>highway: '+feature.properties.highway+'</p>'+'</h1><p>public_transport:'+feature.properties.public_transport+'</p>');
					  }
					}).addTo(mymap);*/
				
					//Tích hợp LRM
					routeControl = L.Routing.control({
						    waypoints: [
						                 L.latLng(10.777061, 106.705806),
						                 L.latLng(10.773241, 106.706412)
						             ],
						    router: L.Routing.graphHopper('16367e37-761c-49a9-b132-86e81ff97a23'),
						    vehicle: "walk",
						    routeWhileDragging: true,
						    show: true,
						    autoRoute: true
					}).addTo(mymap);
				
				/*	var latlngs = [
						    [10.777061, 106.705806],
						    [10.773241, 106.706412],
						    [10.770885, 106.705645],
						    [10.771054, 106.701869],
						    [10.771022, 106.699734],
						    [10.770843, 106.698468]
						];
						var polyline = L.polyline(latlngs, {color: 'red'}).addTo(mymap);
						// zoom the map to the polyline
						mymap.fitBounds(polyline.getBounds());*/
					//Tỉ lệ scale bảng đồ
					L.control.scale().addTo(mymap); 			
		</script>			
		<script type="text/javascript" src="lib/jquery/jquery.js"></script>
		<script type="text/javascript" src="lib/jquery/jquery-ui.js"></script>
		<script type="text/javascript" src="lib/leaflet/leaflet-src.js"></script>
		<script type="text/javascript" src="js/main.js"></script> 
		<script type="text/javascript" src="js/timduong.js"></script>