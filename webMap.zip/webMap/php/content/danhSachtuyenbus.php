<?php
#---------------------------------------------Thêm trạm bus---------------------------------
	if(isset($_POST['themtram'])){
		echo "<div class='tieude'>THÊM TRẠM XE BUS VÀO TUYẾN</div>";
		if(!empty($_POST['chon'])){
			require("connect.php");
			$checkbox =$_POST['chon'];
			$len=count($checkbox);
			if($len==1){
				echo "<form name='themtrambus' method='POST' action='#'>";
				echo "<table border='1' class='tabletuyenbus'>";
					echo "<tr><th width='3%'>Mã tuyến</th>".
								"<th>Mã trạm</th>".
								"<th>Tên trạm</th>".
								"<th>Lat</th>".
								"<th>Lon</th>".
								"<th>STT theo tuyến</th>".
								"</tr>";
					for( $i=0;$i<$len;$i++){
						echo "<tr>";
						$sql = "select * FROM tuyen_xebus WHERE ma_sotuyen='".$checkbox[$i]."'";
							$retval = mysqli_query($conn,$sql)
								or die(mysqli_error());
						if(mysqli_num_rows($retval) > 0){					
								while($row = mysqli_fetch_assoc($retval)){
								    echo "<td> <input name='mst' type='hidden' value='{$row['ma_sotuyen']}'>{$row['ma_sotuyen']}</td>";
								    echo "<td> <input name='ma_tram' type='text'></td>"; 
									echo "<td> <input name='ten_tram' type='text'</td>"; 
									echo "<td> <input name='lat' type='text'></td>";
									echo "<td> <input name='lon'></td>";
									echo "<td> <input name='stt_theotuyen'></td>";
								}
						}
						 echo "</tr> ";							
					}
					echo "</table>";
					echo "<center>";
						echo "<div class='nutchon'>";
							echo "<input class='btn btn-primary' type='submit' name='themtrambus' value='Xác nhận thêm trạm bus vào tuyến'>";
						echo "</center>";
					echo "</form>";
		}else  echo "<script> alert('Bạn chỉ chọn tối đa 1 tuyến bus!')</script>";
	}else echo "<script> alert('Vui lòng chọn ít nhất 1 tuyến bus!')</script>";
}

#---------------------------------Xóa tuyến bus--------------------------------------
if(isset($_POST['xoa'])){
	if(!empty($_POST['chon'])){
				$checkbox =$_POST['chon'];
				$len=count($checkbox);
				require("connect.php");
						for( $i=0;$i<$len;$i++){
							$sql = "DELETE FROM tuyen_xebus WHERE ma_sotuyen='".$checkbox[$i]."'";
							$retval = mysqli_query($conn,$sql)
								or die(mysqli_error());
								
				}
				echo "<script>alert('Đã xóa thành công!')</script>";      
	}else echo "<script> alert('Vui lòng chọn ít nhất một tuyến bus!')</script>";
}

#----------Cập nhật tuyến bus-----------------
	if(isset($_POST['capnhat'])){
	require("connect.php");
		$sql = "UPDATE tuyen_xebus SET ten_tuyen='{$_POST['ten_tuyen']}',
				donvi_damnhan='{$_POST['donvi_damnhan']}',
				dodai_tuyen='{$_POST['dodai_tuyen']}',
				loai_xe='{$_POST['loai_xe']}',
				gia_ve='{$_POST['gia_ve']}',
				ma_tinhthanh='{$_POST['ma_tinhthanh']}',
				so_chuyen='{$_POST['so_chuyen']}',
				tu='{$_POST["tu"]}',
				den='{$_POST["den"]}',
				giancach_chuyen='{$_POST['giancach_chuyen']}'
		WHERE ma_sotuyen='{$_POST['ma_sotuyen']}'";
	   mysqli_query($conn, $sql) or die("<script> alert('Cập nhật không thành công!')</script>");
	   echo "<script> alert('Cập nhật thành công!')</script>";
	}

#----------Thêm trạm bus vào tuyến bus-----------------
	if(isset($_POST['themtrambus'])){
	require("connect.php");
		$sql = "INSERT INTO tram_xebus(ma_tram,ten_tram,ma_sotuyen,lat,lon,stt_theotuyen ) VALUES('{$_POST['ma_tram']}','{$_POST['ten_tram']}','{$_POST['mst']}','{$_POST['lat']}','{$_POST['lon']}','{$_POST['stt_theotuyen']}');";
	   mysqli_query($conn, $sql) 
	   		or die("<script> alert('Thêm không thành công!')</script>");
	   echo "<script> alert('Thêm thành công!')</script>";
	}

#---------------------------------Sửa tuyến bus--------------------------------------
if(isset($_POST['sua'])){
		if(!empty($_POST['chon'])){
			require("connect.php");
			$checkbox =$_POST['chon'];
			$len=count($checkbox);
			if($len==1){
				echo "<form name='sua' method='post' action='#'>";
					echo "<table border='1' class='tabletuyenbus'>";
							echo "<tr>";
							echo "<th width='5%'>Mã tuyến</th>"; 
							echo "<th>Tên tuyến</th>"; 
							echo "<th>ĐV đảm nhận</th>"; 
							echo "<th width='5%'>Độ dài tuyến</th>"; 
							echo "<th width='8%'>Loại xe</th>"; 
							echo "<th width='10%'>Giá vé</th>";
							echo "<th width='6%'>Tỉnh thành</th>"; 
							echo "<th width='5%'>Số chuyến</th>"; 
							echo "<th width='13%'>Từ</th>"; 
							echo "<th width='13%'>Đến</th>"; 
							echo "<th width='8%'>Giản cách chuyến</th>";
							echo "</tr>";
					for( $i=0;$i<$len;$i++){
						echo "<tr>";
						$sql = "select * FROM tuyen_xebus WHERE ma_sotuyen='".$checkbox[$i]."'";
							$retval = mysqli_query($conn,$sql)
								or die(mysqli_error());
						if(mysqli_num_rows($retval) > 0){					
								while($row = mysqli_fetch_assoc($retval)){
								    echo "<td> <input name='ma_sotuyen' type='text' value='{$row['ma_sotuyen']}'></td>";
									echo "<td> <input name='ten_tuyen' type='text' value='{$row['ten_tuyen']}'></td>"; 
									echo "<td> <input name='donvi_damnhan' type='text' value='{$row['donvi_damnhan']}'></td>";
									echo "<td> <input name='dodai_tuyen' type='text' value='{$row['dodai_tuyen']}'></td>"; 
									echo "<td> <input name='loai_xe' type='text' value='{$row['loai_xe']}'></td>";
									echo "<td> <input name='gia_ve' type='text' value='{$row['gia_ve']}'></td>";
									echo "<td> <input name='ma_tinhthanh' type='text' value='{$row['ma_tinhthanh']}'></td>";
									echo "<td> <input name='so_chuyen' type='text' value='{$row['so_chuyen']}'></td>";
									echo "<td> <input name='tu' type='time' value='{$row['tu']}'></td>";
									echo "<td> <input name='den' type='time' value='{$row['den']}'></td>";		
									echo "<td> <input name='giancach_chuyen' type='number' value='{$row['giancach_chuyen']}'></td>";					
								}
						}
						 echo "</tr> ";							
					}
					echo "</table>";
						echo "<center>";
						echo "<div class='nutchon'>";
							echo "<input class='btn btn-primary' type='submit' name='capnhat' value='Cập nhật'>";
						echo "</center>";
						echo "</div>";
					echo "</form>";
			}else  echo "<script> alert('Bạn chỉ chọn tối đa 1 tuyến!')</script>";	
		}else echo "<script> alert('Vui lòng chọn ít nhất 1 tuyến!')</script>";
	}
?>
<div class="tieude">DANH SÁCH TUYẾN BUS</div>
<?php
include("connect.php");
	$sql="SELECT * FROM tuyen_xebus";
	$retval=mysqli_query($conn, $sql);
	if(mysqli_num_rows($retval) > 0){	
	echo "<form name='quanly' method='post' action='#'>";
	echo "<table border='1' class='tabletuyenbus'>";
	echo "<tr>		<th width='5%'>Mã tuyến</th>".
					"<th>Tên tuyến</th>".
					"<th>ĐV đảm nhận</th>".
					"<th width='5%'>Độ dài tuyến</th>".
					"<th width='8%'>Loại xe</th>".
					"<th width='10%'>Giá vé</th>".
					"<th width='6%'>Tỉnh thành</th>".
					"<th width='5%'>Số chuyến</th>".
					"<th width='9%'>Từ</th>".
					"<th width='9%'>Đến</th>".
					"<th width='8%'>Giãn cách chuyến</th>".
					"<th width='auto'>Chi Tiết</th>
					<th>Chọn</th>
					
         </tr>";			
		while($row = mysqli_fetch_assoc($retval)){
			$sql="SELECT count(*) as sotram FROM tram_xebus where ma_sotuyen='{$row["ma_sotuyen"]}'";
			$retval2=mysqli_query($conn, $sql);
			$sotram=mysqli_fetch_assoc($retval2);
				echo "<tr>";
				echo "<td>" . $row["ma_sotuyen"]. "</td>"; 
				echo "<td>" . $row["ten_tuyen"]. "</td>"; 
				echo "<td>" . $row["donvi_damnhan"]. "</td>"; 
				echo "<td>" . $row["dodai_tuyen"]. "</td>"; 
				echo "<td>" . $row["loai_xe"]. "</td>"; 
				echo "<td>" . $row["gia_ve"]. "</td>"; 
				echo "<td>" . $row["ma_tinhthanh"]. "</td>"; 
				echo "<td>" . $row["so_chuyen"]. "</td>"; 
				echo "<td>" . $row["tu"]. "</td>"; 
				echo "<td>" . $row["den"]. "</td>"; 
				echo "<td>" . $row["giancach_chuyen"]."</td>";
				if($sotram['sotram']>0)
				echo "<td><a href='index.php?xem=danhsachtrambus&id={$row['ma_sotuyen']}'>
				<i class='fas fa-eye'></i>
				</a></td>";
				else echo "<td><a name='{$row['ma_sotuyen']}' onClick=thongbaorong(name);>
				<i class='fas fa-eye-slash'></i>
				</a></td>";
				echo "<td style='width:40px;'><input type='checkbox' name='chon[]' value='".$row["ma_sotuyen"]."'></td>";
				echo "</tr>";
		}	
		echo "</table>";
		echo "<center>";
					echo "<div class='nutchon'>";
						echo "<input class='btn btn-primary' name='themtram' type='submit' value='Thêm Trạm Bus'></td>";
						echo "<input class='btn btn-primary' name='xoa' type='submit' value='Xóa Tuyến Bus'></td>";
						echo "<input class='btn btn-primary' name='sua' type='submit' value='Sửa Tuyến Bus'></td>";
					echo "</div>";
		echo "</center>";
	echo "</form>";
}else echo "Không có tuyến bus!";	
mysqli_close($conn);
?>

<?php
if(isset($_POST['xemtram'])){	
?>
<?php
if(!empty($_POST['chon'])){
	require("connect.php");
	$checkbox =$_POST['chon'];
	$len=count($checkbox);
	if($len==1){
		echo "<div class='tieude'>DANH SÁCH TRẠM BUS THUỘC TUYẾN {$checkbox[0]}</div>";
		$sql="SELECT * FROM tram_xebus where ma_sotuyen='{$checkbox[0]}'";
		$retval=mysqli_query($conn, $sql);
		if(mysqli_num_rows($retval) > 0){	
		echo "<form name='quanly' method='post' action='#'>";
		echo "<table border='1' class='tabletuyenbus'>";
		echo "<tr>		<th width='10%' >Mã trạm</th>".
						"<th>Tên trạm</th>".
						"<th width='20%'>Vĩ độ(Latitude)</th>".
						"<th width='20%'>Kinh độ(Longitude)</th>".
						"<th width='10%'>STT Theo Tuyến</th>".
						"<th>Chọn</th>".
	         "</tr>";			
		while($row = mysqli_fetch_assoc($retval)){
				echo "<tr>";
				echo "<td style='text-align:center;'>" . $row["ma_tram"]. "</td>"; 
				echo "<td>" . $row["ten_tram"]. "</td>"; 
				echo "<td style='text-align:center;'>" . $row["lat"]. "</td>"; 
				echo "<td style='text-align:center;'>" . $row["lon"]. "</td>"; 
				echo "<td style='text-align:center;'>" . $row["stt_theotuyen"]. "</td>";
				echo "<td style='width:40px;'><input type='checkbox' name='chon[]' value='".$row["ma_tram"]."'></td>";
				echo "</tr>";
		}	
		echo "</table>";
		echo "<center>";
					echo "<div class='nutchon'>";
						echo "<a class='btn btn-primary' name='suatram'>Sửa trạm</a></td>";
					echo "</div>";
		echo "</center>";
		echo "</form>";
		}else echo "Không có trạm bus thuộc tuyến!";	
		mysqli_close($conn);
	}else  echo "<script> alert('Bạn chỉ chọn tối đa 1 tuyến!')</script>";
}else echo "<script> alert('Vui lòng chọn ít nhất 1 tuyến!')</script>";
}
?>
<script type="text/javascript">
	function thongbaorong(mst){
		alert('Không có trạm bus trong tuyến '+mst);
	}

</script>