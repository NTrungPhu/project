﻿<div id="menu-dienthoai"> <a href="#"> <img  src="img/menu-mobie.png"/> </a> </div>
	<ul id="nav" class="nav nav-tabs" role="tablist">
		<li><a href="index.php">Trang Chủ</a></li>
		<li><a href="index.php?xem=themtuyenbus">Thêm Tuyến Bus</a></li>
		<li><a href="index.php?xem=timtuyenbus">Tìm Tuyến Bus</a></li> 							
	</ul>