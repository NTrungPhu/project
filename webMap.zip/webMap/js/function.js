function danhsachtuyenbus(){
	alert("OK");
}