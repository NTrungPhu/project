## 2.2.0 (2015-03-03)


#### Bug Fixes

* **OSRM:** make sure waypoint options exist before checking them. ([2dd9d778]([object Object]/commit/2dd9d778baae30f0ef7f2d535a9d12ee7283a500))


#### Features

* **plan:** routeWhileDragging also used when adding a new waypoint by dragging the route li ([6ab58fb2]([object Object]/commit/6ab58fb25d56f650ab0af4e168748e2997070582))


