<style type="text/css">
	.table{
		position: relative;
		float: left;
		margin-top: 2%;
	}
	.table input{
		width: 100%;
	}
</style>
<script type="text/javascript">
	function themtrambyMAP(){
		 id=$("[type=radio]:checked").val(); 
		 if(id==null) {alert(" chưa chọn tuyến");return 0;}
		window.location="index.php?xem=themtuyenbymap&id="+id+"#mapid";
	
	}
</script>
<?php
#---------------------------------------------Thêm trạm bus---------------------------------
	if(isset($_POST['themtram'])){
		if(!empty($_POST['chon'])){
			echo "<div class='tieude'>THÊM TRẠM XE BUS VÀO TUYẾN</div>";
			require("connect.php");
			$checkbox =$_POST['chon'];
			if($checkbox!=null){
				echo "<form name='themtrambus' method='POST' action='#'>";
				echo "<table class='table table-hover'>";
					echo "<tr><th width='10%'>Mã tuyến</th>".
								"<th>Mã trạm</th>".
								"<th>Tên trạm</th>".
								"<th>Lat</th>".
								"<th>Lon</th>".
								"<th>STT theo tuyến</th>".
								"</tr>";
				
						echo "<tr>";
						$sql = "select * FROM tuyen_xebus WHERE ma_sotuyen='".$checkbox."'";
							$retval = mysqli_query($conn,$sql)
								or die(mysqli_error());
						if(mysqli_num_rows($retval) > 0){					
								while($row = mysqli_fetch_assoc($retval)){
								    echo "<td style='text-align:center; padding:22px;'> <input name='mst' type='hidden' value='{$row['ma_sotuyen']}'>{$row['ma_sotuyen']}</td>";
								    echo "<td> <input name='ma_tram' type='text'></td>"; 
									echo "<td> <input name='ten_tram' type='text'</td>"; 
									echo "<td> <input name='lat' type='text'></td>";
									echo "<td> <input name='lon'></td>";
									echo "<td> <input name='stt_theotuyen'></td>";
								}
						}
						 echo "</tr> ";							
					
					echo "</table>";
					echo "<center>";
						echo "<div class='nutchon'>";
							echo "<input class='btn btn-primary' type='submit' name='themtrambus' value='Xác nhận thêm trạm bus vào tuyến'>";
						echo "</center>";
					echo "</form>";
		}else  echo "<script> alert('Bạn chỉ chọn tối đa 1 tuyến bus!')</script>";
	}else echo "<script> alert('Vui lòng chọn ít nhất 1 tuyến bus!')</script>";
}

#----------Thêm trạm bus vào tuyến bus-----------------
	if(isset($_POST['themtrambus'])){
	require("connect.php");
		$sql = "INSERT INTO tram_xebus(ma_tram,ten_tram,ma_sotuyen,lat,lon,stt_theotuyen ) VALUES('{$_POST['ma_tram']}','{$_POST['ten_tram']}','{$_POST['mst']}',{$_POST['lat']},{$_POST['lon']},{$_POST['stt_theotuyen']});";
		echo $sql;
	   mysqli_query($conn, $sql) 
	   		or die("<script> alert('Thêm không thành công!')</script>");
	   echo "<script> alert('Thêm thành công!')</script>";
	}

#------------Danh sách các tuyến bus------------------------
echo "<div class='tieude'>DANH SÁCH CÁC TUYẾN BUS</div>";
include("connect.php");
	$sql="SELECT * FROM tuyen_xebus";
	$retval=mysqli_query($conn, $sql) or die('Không kết nối được');
	if(mysqli_num_rows($retval) > 0){
	echo "<form name='quanly' method='post' action='#'>";
	echo "<table class='table table-hover'>";
	echo "<tr>		<th width='10%' scope='col'>Mã tuyến</th>".
					"<th scope='col'>Tên tuyến</th>".
					"<th width='15%' scope='col'>Tỉnh thành</th>".
					"<th scope='col'>Chọn</th>		
         </tr>";	
		while($row = mysqli_fetch_assoc($retval)){
			$sql="SELECT count(*) as sotram FROM tram_xebus where ma_sotuyen='{$row["ma_sotuyen"]}'";
			$retval2=mysqli_query($conn, $sql);
			$sotram=mysqli_fetch_assoc($retval2);
				echo "<tr>";
				echo "<td>" . $row["ma_sotuyen"]. "</td>"; 
				echo "<td>" . $row["ten_tuyen"]. "</td>"; 
				echo "<td>" . $row["ma_tinhthanh"]. "</td>"; 
				echo "<td style='width:40px;'><input type='radio' name='chon' value='".$row["ma_sotuyen"]."'></td>";
				echo "</tr>";
		}	
		echo "</table>";
		echo "<center>";
					echo "<div class='nutchon'>";
						echo "<input class='btn btn-primary' name='themtram' type='submit' value='Thêm Trạm Bus Vào Tuyến Bus'></td>";
						echo "<input class='btn btn-primary' id='themtrambymap' name='themtrambymap' type='button' onclick='themtrambyMAP();' value='Thêm Trạm Bus Vào Tuyến Bus By Map'></td>";
		echo "</center>";
	echo "</form>";
}else echo "Không có tuyến bus!";	
mysqli_close($conn);
?>