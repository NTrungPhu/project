﻿<div id="menu-dienthoai"> <a href="#"> <img  src="img/menu-mobie.png"/> </a> </div>
	<ul id="nav" class="nav nav-tabs" role="tablist">
		<li><a href="index.php?xem=themtuyenbus">Thêm Tuyến</a></li>
		<li><a href="index.php?xem=danhsachtuyenbus">Danh Sách Tuyến</a></li>
		<li><a href="index.php?xem=themtrambusvaotuyenbus">Thêm Trạm Vào Tuyến</a></li>
		<li><a href="index.php?xem=dangthongbao">Đăng Thông Báo</a></li>
		<li><a href="index.php?xem=timtuyenbus">Tìm Tuyến</a></li>
		<li><a href="index.php?xem=themtuyenbymap">Thêm Tuyến By Map</a></li>
	</ul>